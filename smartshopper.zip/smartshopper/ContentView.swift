//
//  ContentView.swift
//  smartshopper
//
//  Created by Bakim Boadu on 2025-02-10.
//

import SwiftUI

struct ShoppingList: Identifiable {
    var id = UUID()
    var name: String
    var totalCost: Double
}

struct ContentView: View {
    @State private var shoppingLists: [ShoppingList] = [
        ShoppingList(name: "Groceries", totalCost: 45.75),
        ShoppingList(name: "Electronics", totalCost: 299.99)
    ]
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(shoppingLists) { list in
                        NavigationLink(destination: ShoppingListDetailView(shoppingList: list)) {
                            HStack {
                                Text(list.name)
                                    .font(.headline)
                                Spacer()
                                Text("$\(list.totalCost, specifier: "%.2f")")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
                
                NavigationLink(destination: AddShoppingListView(shoppingLists: $shoppingLists)) {
                    Text("Create New Shopping List")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
            }
            .navigationTitle("Shopping Lists")
            .toolbar {
                NavigationLink(destination: SettingsView()) {
                    Image(systemName: "gear")
                }
            }
        }
    }
}


struct ShoppingListDetailView: View {
    var shoppingList: ShoppingList
    
    var body: some View {
        VStack {
            Text("Editing \(shoppingList.name)")
                .font(.title)
            Spacer()
        }
        .navigationTitle("List Details")
    }
}


struct AddShoppingListView: View {
    @Binding var shoppingLists: [ShoppingList]
    @State private var listName = ""
    
    var body: some View {
        VStack {
            TextField("Enter list name", text: $listName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button("Add List") {
                if !listName.isEmpty {
                    shoppingLists.append(ShoppingList(name: listName, totalCost: 0.0))
                }
            }
            .padding()
            .background(Color.green)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
    }
}


struct SettingsView: View {
    var body: some View {
        VStack {
            Text("Manage Categories & Data")
                .font(.headline)
            Button("Clear Data") {
                
            }
            .foregroundColor(.red)
            
            Button("Export Data") {
                
            }
        }
        .padding()
        .navigationTitle("Settings")
    }
}


struct LaunchView: View {
    @State private var isActive = false
    
    var body: some View {
        if isActive {
            ContentView()
        } else {
            VStack {
                Text("Shopping List App")
                    .font(.largeTitle)
                Text("Developed by Bakim Boadu")
                    .font(.subheadline)
                    .padding(.top, 10)
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    isActive = true
                }
            }
        }
    }
}

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        LaunchView()
    }
}
