//
//  smartshopperApp.swift
//  smartshopper
//
//  Created by Bakim Boadu on 2025-02-16.
//

import SwiftUI

@main
struct smartshopperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
